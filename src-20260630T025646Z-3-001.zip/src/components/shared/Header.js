import React from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import '../../styles/Header.css';

const Header = () => {
    const { user, signOut } = useAuth();
    const navigate = useNavigate();

    const handleLogout = async () => {
        await signOut();
        navigate('/login');
    };

    return (
        <>
            <div className="header-banner">
                Ekiti Digital Governance Platform
            </div>
            <header className="header">
                <div className="header-container">
                    <div className="header-left">
                        <Link to="/dashboard" className="header-logo">
                            <span className="logo-icon">🏛️</span>
                            <span className="logo-text">DiGoP</span>
                            {/* <span className="logo-badge">COMMAND CENTER</span> */}
                        </Link>
                    </div>

                    <nav className="header-nav">
                        <NavLink to="/dashboard" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                            <i className="fas fa-home"></i> Home
                        </NavLink>
                        <NavLink to="/projects" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                            <i className="fas fa-project-diagram"></i> Projects
                        </NavLink>
                        <NavLink to="/departments" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                            <i className="fas fa-building"></i> Departments
                        </NavLink>
                        {/*<NavLink to="/network" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                            <i className="fas fa-network-wired"></i> Network
                        </NavLink>*/}
                        <NavLink to="/sentiment" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                            <i className="fas fa-chart-line"></i> Sentiment
                        </NavLink>
                        <NavLink to="/video-call" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                            <i className="fas fa-video"></i> Video
                        </NavLink>
                        <NavLink to="/approvals" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                            <i className="fas fa-check-circle"></i> Approvals
                        </NavLink>
                        <NavLink to="/audit" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                            <i className="fas fa-history"></i> Audit
                        </NavLink>
                    </nav>

                    <div className="header-right">
                        {user && (
                            <div className="user-menu">
                                <span className="user-name">
                                    <i className="fas fa-user-circle"></i>
                                    {user.user_metadata?.full_name || 'Official'}
                                </span>
                                <button onClick={handleLogout} className="logout-btn">
                                    <i className="fas fa-sign-out-alt"></i> EXIT
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </header>
        </>
    );
};

export default Header;